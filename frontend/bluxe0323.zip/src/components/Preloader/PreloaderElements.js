import styled from "styled-components";
import { motion } from "framer-motion";

export const Div = styled(motion.div)`
  background: rgba(0, 0, 0, 1);
  display: flex;
  min-height: 100vh;
  height: max-content;
  background-size: 100vw 100vh;
  align-items: center;
  justify-content: center;
`;

export const Video = styled(motion.video)`
  height: 500px;
  width: 400px;
  scale: 2;
  position: relative;
  @media (max-width: 1024px) {
    margin-top: 50px;
  }
`;
