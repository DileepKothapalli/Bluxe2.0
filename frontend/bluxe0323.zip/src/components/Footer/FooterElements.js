import { motion } from "framer-motion";
import styled, { css, keyframes } from "styled-components";
import bg1 from "../../images/Blackbackground2.jpg";
import bg2 from "../../images/blacklight.jpg";
import bg3 from "../../images/blackmanbackground.jpg";
import bg4 from "../../images/blackbackground.jpg";
import bg5 from "../../images/darkpurple.jpg";
import bg6 from "../../images/lightbackground.jpg";
import bg7 from "../../images/linebackground.jpg";
export const Div = styled(motion.div)`
  display: flex;
  // min-height: 30vh;
  height: max-content;
  background: rgba(10, 10, 10, 1);
  border-top: 1px solid rgba(255, 255, 255, 0.2);
  padding: 10px 0px 30px;
`;
export const Container = styled(motion.div)`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-evenly;
`;
export const TopContainer = styled(motion.div)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100vw;
`;
export const MidContainer = styled(motion.div)`
  display: flex;
  align-items: center;
  justify-content: center;
  width: 100vw;
`;
export const BottomContainer = styled(motion.div)`
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 30px;
  width: 100vw;
`;

export const Heading = styled.h1`
  font-family: "Playfair Display", serif;
  text-align: center;
  font-size: 45px;
  margin-top: 30px;
  color: white;
  @media (max-width: 550px) {
    font-size: 30px;
  }
`;
export const Button = styled.button`
  margin-top: 20px;
  background-color: green;
  padding: 10px 30px;
  outline: none;
  border: none;
  font-family: "Playfair Display", serif;
  border-radius: 4px;
`;

export const LeftText = styled.h1`
  font-family: "Playfair Display", serif;
  font-size: 20px;
  color: white;
`;

export const RightText = styled.h1`
  color: white;
  font-size: 20px;
  font-family: "Playfair Display", serif;
`;
